
# Resume Coach App with AI (LLM-Powered)

This Streamlit app helps users with their job application documents and preparation using AI.
Built using:
- LangChain + Ollama (llama3.2:1b)
- Streamlit
- gTTS for text-to-speech
- PDF parsing with PyPDF
- Fully local inference (no paid API required)

## Features:
✅ Resume Generator  
✅ Cover Letter Generator  
✅ CV Analyzer  
✅ LinkedIn Summary Generator  
✅ Mock Interview Chatbot  
✅ CV Summary Generator  
✅ Skill Gap Analyzer  
✅ Resume Scoring (Out of 10)  
✅ Keyword Extractor  
✅ Experience Calculator  
✅ 🗣️ Text-to-Speech (CV Summary)

## How to Run

1. Install dependencies:
```
pip install -r requirements.txt
```

2. Pull the model using Ollama:
```
ollama pull llama3.2:1b
```

3. Run the app:
```
streamlit run app.py
```
