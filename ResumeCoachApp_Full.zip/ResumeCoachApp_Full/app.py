import streamlit as st
from google.generativeai import GenerativeModel, configure
from dotenv import load_dotenv
import os
from gtts import gTTS
import tempfile
from langdetect import detect

# Load API key from .env file
load_dotenv()
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
configure(api_key=GOOGLE_API_KEY)

# Load Gemini model
model = GenerativeModel("gemini-1.5-flash")

# Function to get response from Gemini
def generate_response(prompt):
    response = model.generate_content(prompt)
    return response.text

# Streamlit App Config
st.set_page_config(page_title="Resume Coach App", layout="centered")
st.title("📋 Resume Coach App")

# Sidebar for feature selection
features = [
    "Resume Generator",
    "Cover Letter Generator",
    "CV Analyzer",
    "LinkedIn Summary Generator",
    "Mock Interview Chatbot",
    "Job Recommendation",
    "Gap Analysis",
    "CV Scoring",
    "Keyword Highlighter",
    "CV Summary (Text + Audio)",
    "Language Detection"
]
selected_feature = st.sidebar.selectbox("Select a Feature", features)

# ==================== FEATURES ==================== #

if selected_feature == "Resume Generator":
    st.subheader("📄 Resume Generator")
    name = st.text_input("Enter your full name")
    education = st.text_area("Enter your education")
    experience = st.text_area("Enter your experience")
    skills = st.text_area("Enter your skills")
    if st.button("Generate Resume"):
        prompt = f"Create a professional resume for:\nName: {name}\nEducation: {education}\nExperience: {experience}\nSkills: {skills}"
        st.success(generate_response(prompt))

elif selected_feature == "Cover Letter Generator":
    st.subheader("📝 Cover Letter Generator")
    job_title = st.text_input("Enter the job title")
    your_background = st.text_area("Enter your background and motivation")
    if st.button("Generate Cover Letter"):
        prompt = f"Write a professional cover letter for the position of {job_title}.\nBackground: {your_background}"
        st.success(generate_response(prompt))

elif selected_feature == "CV Analyzer":
    st.subheader("📊 CV Analyzer")
    uploaded_cv = st.file_uploader("Upload your CV", type=["txt", "pdf"])
    if uploaded_cv:
        cv_text = uploaded_cv.read().decode("utf-8", errors="ignore")
        prompt = f"Analyze this CV and suggest improvements:\n{cv_text}"
        st.info(generate_response(prompt))

elif selected_feature == "LinkedIn Summary Generator":
    st.subheader("💼 LinkedIn Summary Generator")
    name = st.text_input("Enter your name")
    profession = st.text_input("Enter your profession")
    bio = st.text_area("Enter a short bio or career story")
    if st.button("Generate LinkedIn Summary"):
        prompt = f"Write a LinkedIn summary for {name}, a {profession}. Bio: {bio}"
        st.success(generate_response(prompt))

elif selected_feature == "Mock Interview Chatbot":
    st.subheader("🎤 Mock Interview Chatbot")
    role = st.text_input("Enter the job role you're interviewing for")
    question = st.text_input("Ask an interview question")
    if st.button("Ask"):
        prompt = f"As an interviewer for a {role}, answer this question professionally: {question}"
        st.success(generate_response(prompt))

elif selected_feature == "Job Recommendation":
    st.subheader("🧭 Job Recommendation")
    skills = st.text_area("Enter your skills and interests")
    if st.button("Recommend Jobs"):
        prompt = f"Based on these skills and interests, suggest suitable job roles: {skills}"
        st.success(generate_response(prompt))

elif selected_feature == "Gap Analysis":
    st.subheader("📌 Gap Analysis")
    job_role = st.text_input("Enter job role you're targeting")
    uploaded_cv = st.file_uploader("Upload your CV", type=["txt", "pdf"], key="gap")
    if uploaded_cv and job_role:
        cv_text = uploaded_cv.read().decode("utf-8", errors="ignore")
        prompt = f"What important skills are missing in the following resume for a job in {job_role}:\n{cv_text}"
        st.warning(generate_response(prompt))

elif selected_feature == "CV Scoring":
    st.subheader("✅ CV Scoring")
    job_role = st.text_input("Enter job role for scoring")
    uploaded_cv = st.file_uploader("Upload your CV", type=["txt", "pdf"], key="score")
    if uploaded_cv and job_role:
        cv_text = uploaded_cv.read().decode("utf-8", errors="ignore")
        prompt = f"Give a professional score out of 10 for this resume for the job of {job_role}, with explanation:\n{cv_text}"
        st.info(generate_response(prompt))

elif selected_feature == "Keyword Highlighter":
    st.subheader("🧠 Keyword Highlighter")
    job_role = st.text_input("Enter target job role")
    uploaded_cv = st.file_uploader("Upload your CV", type=["txt", "pdf"], key="keywords")
    if uploaded_cv and job_role:
        cv_text = uploaded_cv.read().decode("utf-8", errors="ignore")
        prompt = f"Extract key industry-specific keywords from this resume for {job_role}:\n{cv_text}"
        st.info(generate_response(prompt))

elif selected_feature == "CV Summary (Text + Audio)":
    st.subheader("🗣️ CV Summary (with Audio)")
    job_role = st.text_input("Enter the job role")
    uploaded_cv = st.file_uploader("Upload your CV", type=["txt", "pdf"], key="summary")
    if uploaded_cv and job_role:
        cv_text = uploaded_cv.read().decode("utf-8", errors="ignore")
        prompt = f"Summarize the following CV for the job role of {job_role}:\n{cv_text}"
        summary = generate_response(prompt)
        st.write(summary)

        tts = gTTS(text=summary)
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as tmpfile:
            tts.save(tmpfile.name)
            st.audio(tmpfile.name, format="audio/mp3")

elif selected_feature == "Language Detection":
    st.subheader("🌐 Language Detection")
    text = st.text_area("Enter text to detect language")
    if st.button("Detect Language"):
        try:
            lang = detect(text)
            st.success(f"Detected Language: {lang}")
        except:
            st.error("Could not detect language.")

else:
    st.warning("Select a feature from the sidebar.")
